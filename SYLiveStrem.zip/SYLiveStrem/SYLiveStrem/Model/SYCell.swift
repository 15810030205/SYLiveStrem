//
//  SYCell.swift
//  SYLiveStrem
//
//  Created by 郝松岩 on 2017/8/22.
//  Copyright © 2017年 hsy. All rights reserved.
//

import Foundation
struct SYCell {
    //头像地址
    var portrait = ""
    //名称
    var nickname = ""
    //地址
    var location = ""
    //观看人数
    var viewers = 0
    //直播地址
    var url = ""

}

